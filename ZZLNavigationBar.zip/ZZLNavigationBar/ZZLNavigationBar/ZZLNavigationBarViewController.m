//
//  ZZLNavigationBarViewController.m
//  ZZLNavigationBar
//
//  Created by ZZL on 2017/2/14.
//  Copyright © 2017年 com.GuangZhou Rich Stone Data Technologies Company Limited.ZZL. All rights reserved.
//

#import "ZZLNavigationBarViewController.h"

#define kScreenWith [UIScreen mainScreen].bound.size.width
#define kScreenHeight [UIScreen mainScreen].bound.size.height

@interface ZZLNavigationBarViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>

@end

@implementation ZZLNavigationBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
